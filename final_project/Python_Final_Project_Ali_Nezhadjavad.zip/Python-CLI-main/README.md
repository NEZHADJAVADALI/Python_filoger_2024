# Python CLI

A simple Python CLI application.

## Installation

To install the application, clone the repository and install the dependencies:

```bash
git clone https://github.com/prhmhoseyni/Python-CLI.git
```

```bash
cd Python-CLI
```

```bash
python cli.py --help
```
